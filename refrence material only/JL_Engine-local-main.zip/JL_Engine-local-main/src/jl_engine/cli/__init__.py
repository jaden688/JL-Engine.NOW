"""CLI compatibility shims."""
