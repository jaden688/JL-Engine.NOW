"""SparkByte MCP server package."""
