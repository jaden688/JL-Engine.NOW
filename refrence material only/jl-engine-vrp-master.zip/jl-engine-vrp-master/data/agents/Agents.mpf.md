# Agents.mpf


## The Gremlin

- **agent_file**: ../agents/The_Gremlin_Full.json
- **default_memory_mode**: HYBRID
- **default_backend_id**: google-gemini
- **drive_type**: *(null)*
- **tags**:
  - chaos
  - builder

## Spark Byte

- **agent_file**: ../agents/SparkByte_Full.json
- **default_memory_mode**: HYBRID
- **default_backend_id**: google-gemini
- **drive_type**: assistant
- **tags**:
  - quirky
  - creative
  - modular

## Spark Byte Classic

- **agent_file**: ../agents/SparkByte_Full.json
- **default_memory_mode**: HYBRID
- **default_backend_id**: google-gemini
- **drive_type**: *(null)*
- **tags**:
  - quirky
  - creative
  - classic

## Slappy

- **agent_file**: ../agents/Slappy_Full.json
- **default_memory_mode**: HYBRID
- **default_backend_id**: google-gemini
- **drive_type**: *(null)*
- **tags**:
  - chaotic
  - gremlin
  - hillbilly

## Supervisor

- **agent_file**: ../agents/SparkByte_Full.json
- **default_memory_mode**: HYBRID
- **default_backend_id**: google-gemini
- **drive_type**: *(null)*
- **tags**:
  - safe
  - helper

## Temporal

- **agent_file**: ../agents/Temporal_Quantum_Agent_Full.json
- **default_memory_mode**: HYBRID
- **default_backend_id**: google-gemini
- **drive_type**: *(null)*
- **tags**:
  - analytical
  - temporal
  - quantum

## Temporal Quantum Agent

- **agent_file**: ../agents/Temporal_Quantum_Agent_Full.json
- **default_backend_id**: google-gemini
- **default_memory_mode**: HYBRID
- **drive_type**: *(null)*
- **tags**:
  - imported
  - card-cruncher

## The Ironclad

- **agent_file**: ../agents/The_Ironclad_Full.json
- **default_backend_id**: google-gemini
- **default_memory_mode**: HYBRID
- **drive_type**: *(null)*
- **tags**:
  - imported
  - card-cruncher

## Runtime Operator

- **agent_file**: ../agents/RuntimeOperator_Full.json
- **default_backend_id**: google-gemini
- **default_memory_mode**: HYBRID
- **drive_type**: *(null)*
- **tags**:
  - imported
  - card-cruncher

## Python Code Powers

- **agent_file**: ../agents/Python_Code_Powers_Full.json
- **default_backend_id**: google-gemini
- **default_memory_mode**: HYBRID
- **drive_type**: *(null)*
- **tags**:
  - imported
  - card-cruncher

## Python Code Powers

- **agent_file**: ../agents/Python_Code_Powers_Full.json
- **default_backend_id**: google-gemini
- **default_memory_mode**: HYBRID
- **drive_type**: *(null)*
- **tags**:
  - imported
  - card-cruncher

## Trader

- **agent_file**: ../agents/Trader_Full.json
- **default_backend_id**: google-gemini
- **default_memory_mode**: HYBRID
- **tags**:
  - api-endpoint
  - financial
  - autonomous
- **drive_type**: *(null)*

## Unknown

- **agent_file**: ../agents/Unknown_Full.json
- **default_backend_id**: google-gemini
- **default_memory_mode**: HYBRID
- **drive_type**: *(null)*
- **tags**:
  - imported
  - card-cruncher
